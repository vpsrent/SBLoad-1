package com.sbload.recharge.common;

import com.sbload.recharge.model.Reseller;

import java.util.ArrayList;

public class AppData {
    public static Reseller user = null;

    public static void init() {
        user = null;
    }
}
