package com.sbload.recharge.common.customview;

import android.app.ProgressDialog;
import android.content.Context;

import com.sbload.recharge.R;

public class LoadingDialog extends ProgressDialog {

    Context mContext;
    String mMessage;

    public LoadingDialog(Context context, String message) {
        super(context, R.style.TransparentProgressDialog);

        mContext = context;
        mMessage = message;

        setCancelable(false);
        setMessage(message);

    }
}
