package com.sbload.recharge.executive;

import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.model.account.login.GetResellerRequest;
import com.sbload.recharge.model.account.login.GetResellerResponse;
import com.sbload.recharge.model.account.login.LoginRequest;
import com.sbload.recharge.model.account.login.LoginResponse;
import com.sbload.recharge.model.account.reseller.GetResellersRequest;
import com.sbload.recharge.model.account.reseller.GetResellersResponse;
import com.sbload.recharge.utility.APIUtility;

public class SplashExecutive extends CommonExecutive {
    SplashDisplay display;

    public SplashExecutive(SplashDisplay display) {
        super(display);
        this.display = display;
    }

    public void getUser() {
        GetResellerRequest request = new GetResellerRequest(AppData.user.getUserId());

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<GetResellerResponse>() {
            @Override
            public void onResponse(GetResellerResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.onAutoLogin(false);
                    return;
                }

                display.onAutoLogin(true);

            }
        }, this);
    }

    public interface SplashDisplay extends CommonDisplay {
        void onAutoLogin(boolean isSuccess);
    }
}
