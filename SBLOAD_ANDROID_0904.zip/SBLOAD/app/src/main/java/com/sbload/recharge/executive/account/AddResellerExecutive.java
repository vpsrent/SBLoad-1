package com.sbload.recharge.executive.account;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.account.reseller.AddResellerRequest;
import com.sbload.recharge.model.account.reseller.AddResellerResponse;
import com.sbload.recharge.model.account.reseller.EditResellerRequest;
import com.sbload.recharge.model.service.Service;
import com.sbload.recharge.utility.APIUtility;
import com.sbload.recharge.utility.StringUtility;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class AddResellerExecutive extends CommonExecutive {
    AddResellerDisplay display;

    public AddResellerExecutive(AddResellerDisplay display) {
        super(display);
        this.display = display;
    }

    private int getTypeValueFromCheckStates(ArrayList<Service> services,
                                            ArrayList<Boolean> checkStates) {

        Set<Integer> checkedServices = new HashSet<>();
        for (int index = 0; index < services.size(); index ++) {
            Service service = services.get(index);
            Boolean checked = checkStates.get(index);
            if (checked) {
                checkedServices.add(service.getType());
            }
        }

        int type = 0;
        for (Integer value : checkedServices) {
            type = type + value;
        }

        return type;
    }

    public void addReseller(ArrayList<Service> services, ArrayList<Boolean> checkStates) {
        int type = getTypeValueFromCheckStates(services, checkStates);
        AddResellerRequest request = display.getAddResellerRequest(type);
        if (request == null) {
            return;
        }

        int validateString = validateAddResellerRequest(request);
        if (validateString != R.string.input_validate) {
            display.showError(validateString);
            return;
        }

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<AddResellerResponse>() {
            @Override
            public void onResponse(AddResellerResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }

                if (response.getStatus().getCode() != 0) {
                    return;
                }
                display.showSuccess(R.string.add_reseller_success);
                display.onSuccessAddReseller();
            }
        }, this);
    }

    public void editReseller(ArrayList<Service> services, ArrayList<Boolean> checkStates) {
        int type = getTypeValueFromCheckStates(services, checkStates);

        EditResellerRequest request = display.getEditResellerRequest(type);
        if (request == null) {
            return;
        }

        int validateString = validateEditResellerRequest(request);
        if (validateString != R.string.input_validate) {
            display.showError(validateString);
            return;
        }

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<AddResellerResponse>() {
            @Override
            public void onResponse(AddResellerResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }
                display.onSuccessEditReseller();
            }
        }, this);
    }

    public int validateAddResellerRequest(AddResellerRequest request) {
        if (request.getName().isEmpty()) {
            return R.string.empty_user_name;
        }
        if (request.getPassword().isEmpty()) {
            return R.string.empty_password;
        }
        if (request.getMobile().isEmpty()) {
            return R.string.empty_phone;
        }
        if (request.getEmail().isEmpty()) {
            return R.string.empty_email;
        }
        if (!StringUtility.isValidEmail(request.getEmail())) {
            return R.string.invalid_email;
        }
        if (request.getNote().isEmpty()) {
            return R.string.empty_note;
        }
        if (request.getPin().isEmpty()) {
            return R.string.empty_pin;
        }
        if (request.getType() == 0) {
            return R.string.empty_service;
        }

        return R.string.input_validate;
    }

    public int validateEditResellerRequest(EditResellerRequest request) {
        if (request.getName().isEmpty()) {
            return R.string.empty_user_name;
        }
        if (!request.getPassword().isEmpty() && request.getNewPassword().isEmpty()) {
            return R.string.empty_password;
        }
        if (request.getMobile().isEmpty()) {
            return R.string.empty_phone;
        }
        if (request.getEmail().isEmpty()) {
            return R.string.empty_email;
        }
        if (!StringUtility.isValidEmail(request.getEmail())) {
            return R.string.invalid_email;
        }
        if (request.getNote().isEmpty()) {
            return R.string.empty_note;
        }
        if (request.getType() == 0) {
            return R.string.empty_service;
        }
        if (!request.getPin().isEmpty() && request.getNewPin().isEmpty()) {
            return R.string.empty_pin;
        }

        return R.string.input_validate;
    }

    public interface AddResellerDisplay extends CommonDisplay {
        void onSuccessAddReseller();
        void onSuccessEditReseller();
        AddResellerRequest getAddResellerRequest(int type);
        EditResellerRequest getEditResellerRequest(int type);
    }
}
