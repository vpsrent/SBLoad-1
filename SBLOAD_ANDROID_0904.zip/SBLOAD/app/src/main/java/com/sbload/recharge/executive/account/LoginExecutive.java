package com.sbload.recharge.executive.account;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.account.login.LoginRequest;
import com.sbload.recharge.model.account.login.LoginResponse;
import com.sbload.recharge.utility.APIUtility;
import com.sbload.recharge.utility.StringUtility;

public class LoginExecutive extends CommonExecutive {
    LoginDisplay display;

    public LoginExecutive(LoginDisplay display) {
        super(display);
        this.display = display;
    }

    public void login() {
        LoginRequest request = display.getLoginRequest();
        if (request == null) {
            return;
        }

        int validateString = validateLoginRequest(request);
        if (validateString != R.string.input_validate) {
            display.showError(validateString);
            return;
        }

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<LoginResponse>() {
            @Override
            public void onResponse(LoginResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }
                if (response.getStatus().getCode() == 0) {
                    display.onLoginSuccess(response.getResponseResult().getTwoStepRequire() == 1);
                }
            }
        }, this);
    }

    public int validateLoginRequest(LoginRequest request) {
        if (request.getName().isEmpty()) {
            return R.string.empty_user_name;
        }
        if (request.getPassword().isEmpty()) {
            return R.string.empty_password;
        }

        return R.string.input_validate;
    }

    public interface LoginDisplay extends CommonExecutive.CommonDisplay {
        public void onLoginSuccess(boolean twoStepRequire);
        public LoginRequest getLoginRequest();
    }
}
