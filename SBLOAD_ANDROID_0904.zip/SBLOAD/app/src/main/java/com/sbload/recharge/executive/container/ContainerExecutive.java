package com.sbload.recharge.executive.container;

import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.account.amount.GetAmountRequest;
import com.sbload.recharge.model.account.amount.GetAmountResponse;
import com.sbload.recharge.model.account.login.LoginRequest;
import com.sbload.recharge.model.account.login.LoginResponse;
import com.sbload.recharge.model.service.DashboardItem;
import com.sbload.recharge.model.service.Service;
import com.sbload.recharge.utility.APIUtility;

public class ContainerExecutive extends CommonExecutive {
    ContainerDisplay display;
    SideMenuDisplay sideMenuDisplay;

    private SideMenuItem selectedItem = SideMenuItem.Home;

    public ContainerExecutive(ContainerDisplay display) {
        super(display);
        this.display = display;
    }

    public void setSideMenuDisplay(SideMenuDisplay sideMenuDisplay) {
        this.sideMenuDisplay = sideMenuDisplay;
    }

    public void showLoading(boolean isShow) {
        display.showLoading(isShow);
    }

    public void showAmount() {
        final GetAmountRequest request = new GetAmountRequest(AppData.user.getUserId());

        request.post(new APIUtility.APIResponse<GetAmountResponse>() {
            @Override
            public void onResponse(GetAmountResponse response) {
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }

                AppData.user.setBalance(response.getBalanceDetailInfo().getUsdAmount());
                sideMenuDisplay.refreshAmount(response.getBalanceDetailInfo().getAmount(),
                        response.getBalanceDetailInfo().getCode());
            }
        }, this);
    }

    public void didPressSideMenuItem(SideMenuItem item) {
        if (selectedItem == item) {
            return;
        }
        selectedItem = item;
        display.selectSideMenuItem(item);
    }

    public void didPressSideMenuButton() {
        display.showSideMenu();
    }

    public void didPressDashboardButton(DashboardItem dashboardItem) {
        if (dashboardItem instanceof Service) {
            display.didPressServiceItem((Service)dashboardItem);
            return;
        }

        display.didPressDashboardItem(dashboardItem);
    }

    public enum SideMenuItem {
        Home,
        AddPayments,
        ChangePassword,
        ChangePIN,
        OpenTickets,
        AboutUs,
        LogOut
    }

    public interface ContainerDisplay extends CommonExecutive.CommonDisplay {
        void selectSideMenuItem(SideMenuItem item);
        void didPressServiceItem(Service service);
        void didPressDashboardItem(DashboardItem dashboardItem);
        void showSideMenu();
    }

    public interface SideMenuDisplay extends CommonExecutive.CommonDisplay {
        void refreshAmount(String amount, String code);
    }
}
