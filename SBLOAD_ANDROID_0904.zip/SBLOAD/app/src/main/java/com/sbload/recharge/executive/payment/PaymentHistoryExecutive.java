package com.sbload.recharge.executive.payment;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.payment.GetPaymentsRequest;
import com.sbload.recharge.model.payment.GetPaymentsResponse;
import com.sbload.recharge.model.payment.TransferLog;
import com.sbload.recharge.model.service.GetHistoriesRequest;
import com.sbload.recharge.model.service.GetHistoriesResponse;
import com.sbload.recharge.model.service.ServiceRequest;
import com.sbload.recharge.utility.APIUtility;

import java.util.ArrayList;

public class PaymentHistoryExecutive extends CommonExecutive {
    PaymentHistoryDisplay display;

    public PaymentHistoryExecutive(PaymentHistoryDisplay display) {
        super(display);
        this.display = display;
    }

    public void requestGetHistories() {
        GetPaymentsRequest request = display.getPaymentsRequest();
        int validateString = validateGetPaymentsHistoriesRequest(request);
        if (validateString != R.string.input_validate) {
            display.showError(validateString);
            return;
        }

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<GetPaymentsResponse>() {
            @Override
            public void onResponse(GetPaymentsResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }

                display.onGetHistories(response.getTransferLogs());
            }
        }, this);
    }

    public int validateGetPaymentsHistoriesRequest(GetPaymentsRequest request) {
        return R.string.input_validate;
    }



    public interface PaymentHistoryDisplay extends CommonDisplay {
        void onGetHistories(ArrayList<TransferLog> histories);
        GetPaymentsRequest getPaymentsRequest();
    }
}
