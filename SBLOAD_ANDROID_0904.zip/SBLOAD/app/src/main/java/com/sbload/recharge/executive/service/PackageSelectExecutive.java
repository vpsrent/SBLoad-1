package com.sbload.recharge.executive.service;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.service.GetPackageOperatorsRequest;
import com.sbload.recharge.model.service.GetPackageOperatorsResponse;
import com.sbload.recharge.model.service.GetPackagesRequest;
import com.sbload.recharge.model.service.GetPackagesResponse;
import com.sbload.recharge.model.service.PackageOperator;
import com.sbload.recharge.model.service.ServicePackage;
import com.sbload.recharge.utility.APIUtility;

import java.util.ArrayList;

public class PackageSelectExecutive extends CommonExecutive {
    PackageSelectDisplay display;
    private PackageOperator selectedOperator = null;

    public PackageSelectExecutive(PackageSelectDisplay display) {
        super(display);
        this.display = display;
    }

    public void getPackages(Integer operatorId) {
        GetPackagesRequest request = new GetPackagesRequest(operatorId);
        display.showLoading(true);
        request.post(new APIUtility.APIResponse<GetPackagesResponse>() {
            @Override
            public void onResponse(GetPackagesResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }

                display.didGetPackages(response.getPackages());
            }
        }, this);
    }



    public interface PackageSelectDisplay extends CommonDisplay {
        void didGetPackages(ArrayList<ServicePackage> packages);
    }
}
