package com.sbload.recharge.model;

import com.sbload.recharge.model.account.AccountService;
import com.sbload.recharge.model.payment.PaymentService;
import com.sbload.recharge.model.support.SupportService;
import com.sbload.recharge.utility.APIUtility;

public class BaseRequest {
    protected AccountService accountService = APIUtility.getAccountService();
    protected PaymentService paymentService = APIUtility.getPaymentService();
    protected SupportService supportService = APIUtility.getSupportService();
}
