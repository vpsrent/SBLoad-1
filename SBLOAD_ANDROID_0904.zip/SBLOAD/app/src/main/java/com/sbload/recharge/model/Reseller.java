package com.sbload.recharge.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Reseller {

    @SerializedName("id")
    @Expose
    private String userId;

    @SerializedName("username")
    @Expose
    private String userName;

    @SerializedName("balance")
    @Expose
    private String balance;

    @SerializedName("user_type")
    @Expose
    private int userType;

    @SerializedName("admin")
    @Expose
    private int admin;

    @SerializedName("parent")
    @Expose
    private int parent;

    @SerializedName("rs5")
    @Expose
    private int rs5;

    @SerializedName("rs4")
    @Expose
    private int rs4;

    @SerializedName("rs3")
    @Expose
    private int rs3;

    @SerializedName("rs2")
    @Expose
    private int rs2;

    @SerializedName("status")
    @Expose
    private int status;

    @SerializedName("type")
    @Expose
    private int type;

    @SerializedName("fullname")
    @Expose
    private String fullname;

    @SerializedName("mobile")
    @Expose
    private String mobile;

    @SerializedName("email")
    @Expose
    private String email;

    @SerializedName("api_key")
    @Expose
    private String apiKey;

    @SerializedName("api_enable")
    @Expose
    private int apiEnable;

    @SerializedName("note")
    @Expose
    private String note;

    @SerializedName("cookie")
    @Expose
    private String cookie;

    @SerializedName("dlimit")
    @Expose
    private float dlimit;

    @SerializedName("duse")
    @Expose
    private float duse;

    @SerializedName("mask")
    @Expose
    private int mask;

    @SerializedName("device_id")
    @Expose
    private String deviceId;

    public int getType() {
        return type;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMobile() {
        return mobile;
    }

    public String getEmail() {
        return email;
    }

    public String getNote() {
        return note;
    }
}
