package com.sbload.recharge.model.account.amount;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class BalanceDetailInfo {

    @SerializedName("usd_amount")
    @Expose

    private String usdAmount;

    @SerializedName("amount")
    @Expose

    private String amount;

    @SerializedName("code")
    @Expose

    private String code;

    public String getUsdAmount() {
        return usdAmount;
    }

    public String getAmount() {
        return amount;
    }

    public String getCode() {
        return code;
    }
}
