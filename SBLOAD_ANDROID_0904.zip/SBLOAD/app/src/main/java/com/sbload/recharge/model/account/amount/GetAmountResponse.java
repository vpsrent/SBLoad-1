package com.sbload.recharge.model.account.amount;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.account.login.LoginResponseResult;

public class GetAmountResponse extends CommonResponse {

    @SerializedName("response")
    @Expose

    private BalanceDetailInfo balanceDetailInfo;

    public BalanceDetailInfo getBalanceDetailInfo() {
        return balanceDetailInfo;
    }
}
