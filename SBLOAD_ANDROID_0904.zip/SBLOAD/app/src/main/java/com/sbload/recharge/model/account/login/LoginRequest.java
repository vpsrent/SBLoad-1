package com.sbload.recharge.model.account.login;

import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.BaseRequest;
import com.sbload.recharge.utility.APIUtility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginRequest extends BaseRequest {

    private String deviceId;
    private String name;
    private String password;

    public LoginRequest(String deviceId, String name, String password) {
        this.deviceId = deviceId;
        this.name = name;
        this.password = password;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public void post(final APIUtility.APIResponse<LoginResponse> apiResponse,
                     final CommonExecutive executive) {

        accountService.login(deviceId, name, password).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (!executive.validateResponse(response)) {
                    apiResponse.onResponse(response.body());
                    return;
                }

                AppData.user = response.body().getResponseResult().getReseller();
                apiResponse.onResponse(response.body());
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                executive.display.showError(R.string.request_failed);
                apiResponse.onResponse(null);
            }
        });
    }
}
