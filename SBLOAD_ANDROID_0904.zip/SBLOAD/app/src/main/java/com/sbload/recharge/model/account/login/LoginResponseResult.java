package com.sbload.recharge.model.account.login;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.sbload.recharge.model.Reseller;

public class LoginResponseResult {

    @SerializedName("user")
    @Expose
    public Reseller reseller;

    @SerializedName("2step_require")
    @Expose
    public Integer twoStepRequire;

    public Reseller getReseller() {
        return reseller;
    }

    public Integer getTwoStepRequire() {
        return twoStepRequire;
    }
}
