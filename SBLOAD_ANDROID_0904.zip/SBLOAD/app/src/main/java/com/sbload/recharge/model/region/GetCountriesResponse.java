package com.sbload.recharge.model.region;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.sbload.recharge.model.CommonResponse;

import java.util.ArrayList;

public class GetCountriesResponse extends CommonResponse {

    @SerializedName("response")
    @Expose
    public ArrayList<Country> countries;

    public ArrayList<Country> getCountries() {
        return countries;
    }
}
