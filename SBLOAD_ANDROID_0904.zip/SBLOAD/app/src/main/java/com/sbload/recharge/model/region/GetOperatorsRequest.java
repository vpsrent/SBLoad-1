package com.sbload.recharge.model.region;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.BaseRequest;
import com.sbload.recharge.utility.APIUtility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GetOperatorsRequest extends BaseRequest {

    private int countryId;

    public GetOperatorsRequest(int countryId) {
        this.countryId = countryId;
    }

    public void post(final APIUtility.APIResponse<GetOperatorsResponse> apiResponse,
                     final CommonExecutive executive) {

        paymentService.getOperators(countryId).enqueue(new Callback<GetOperatorsResponse>() {
            @Override
            public void onResponse(Call<GetOperatorsResponse> call, Response<GetOperatorsResponse> response) {
                if (!executive.validateResponse(response)) {
                    apiResponse.onResponse(null);
                    return;
                }

                apiResponse.onResponse(response.body());
            }

            @Override
            public void onFailure(Call<GetOperatorsResponse> call, Throwable t) {
                executive.display.showError(R.string.request_failed);
                apiResponse.onResponse(null);
            }
        });
    }
}
