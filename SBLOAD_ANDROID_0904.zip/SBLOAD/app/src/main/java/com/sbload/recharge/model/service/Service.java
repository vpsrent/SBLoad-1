package com.sbload.recharge.model.service;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Service extends DashboardItem {

    @SerializedName("type")
    @Expose
    private Integer type;

    @SerializedName("enable")
    @Expose
    private Integer enable;

    @SerializedName("min_amnt")
    @Expose
    private Integer minAmount;

    @SerializedName("max_amnt")
    @Expose
    private Integer maxAmount;

    @SerializedName("min_length")
    @Expose
    private Integer minLength;

    @SerializedName("max_length")
    @Expose
    private Integer maxLength;

    @SerializedName("risk_amount")
    @Expose
    private float riskAmount;

    @SerializedName("short")
    @Expose
    private Integer shortType;

    @SerializedName("require_pin")
    @Expose
    private Integer requirePIN;

    @SerializedName("logo")
    @Expose
    private String logo;

    public Service(int serviceId, String name, String spaceuri) {
        super(serviceId, name, spaceuri);
    }

    public Integer getType() {
        return type;
    }

    public Integer getEnable() {
        return enable;
    }

    public Integer getMinAmount() {
        return minAmount;
    }

    public Integer getMaxAmount() {
        return maxAmount;
    }

    public Integer getMinLength() {
        return minLength;
    }

    public Integer getMaxLength() {
        return maxLength;
    }

    public float getRiskAmount() {
        return riskAmount;
    }

    public Integer getShortType() {
        return shortType;
    }

    public Integer getRequirePIN() {
        return requirePIN;
    }

    public String getLogo() {
        return logo;
    }
}
