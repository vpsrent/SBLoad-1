package com.sbload.recharge.view.account;

import android.os.Handler;
import android.os.Message;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.account.SignUpExecutive;
import com.sbload.recharge.model.account.signup.SignUpRequest;
import com.sbload.recharge.utility.StringUtility;
import com.sbload.recharge.view.BaseActivity;

public class SignUpActivity extends BaseActivity implements View.OnClickListener, SignUpExecutive.SignUpDisplay {

    private AppCompatEditText editName, editEmail, editMobile;
    private SignUpExecutive executive;

    final int ACTION_GO_TO_LOGIN = 1;
    final int SPLASH_DELAY_TIME = 2500;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == ACTION_GO_TO_LOGIN) {
                finish();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        //
        // Bind Controls
        //

        editName = findViewById(R.id.edit_name);
        editEmail = findViewById(R.id.edit_email);
        editMobile = findViewById(R.id.edit_mobile);

        //
        // Bind Events
        //

        findViewById(R.id.btn_register).setOnClickListener(this);
        findViewById(R.id.btn_go_to_login).setOnClickListener(this);

        executive = new SignUpExecutive(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_register:
                executive.signUp();
                break;
            case R.id.btn_go_to_login:
                finish();
                break;
        }
    }

    @Override
    public void onSuccessSignUp() {
        mHandler.sendEmptyMessageDelayed(ACTION_GO_TO_LOGIN, SPLASH_DELAY_TIME);
    }

    @Override
    public SignUpRequest getSignUpRequest() {
        return new SignUpRequest(StringUtility.deviceId(getApplicationContext()),
                editName.getText().toString(),
                editMobile.getText().toString(),
                editEmail.getText().toString());
    }
}
