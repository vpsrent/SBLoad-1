package com.sbload.recharge.view.account;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;

import com.google.gson.Gson;
import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.common.Constants;
import com.sbload.recharge.executive.account.VerifyCodeExecutive;
import com.sbload.recharge.model.account.pin.VerifyPINRequest;
import com.sbload.recharge.utility.StringUtility;
import com.sbload.recharge.view.BaseActivity;
import com.sbload.recharge.view.container.ContainerActivity;

public class VerifyCodeActivity extends BaseActivity implements View.OnClickListener, VerifyCodeExecutive.VerifyCodeDisplay {

    private AppCompatEditText editPIN;
    private VerifyCodeExecutive executive;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_code);

        //
        // Bind Controls
        //

        editPIN = findViewById(R.id.edit_pin);

        //
        // Define Events
        //

        findViewById(R.id.btn_submit).setOnClickListener(this);

        executive = new VerifyCodeExecutive(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_submit:
                executive.verifyCode();
                break;
        }
    }

    @Override
    public void onSuccessVerifyPIN() {

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor editor =
                preferences.edit();
        editor.putInt("SBLoad_Logged_In", 1);
        editor.putString("SBLoad_AppData", new Gson().toJson(AppData.user));
        editor.commit();

        showActivity(ContainerActivity.class, Constants.ANIMATION_BOTTOM_TO_UP, true);
    }

    @Override
    public VerifyPINRequest getVerifyPINRequest() {
        return new VerifyPINRequest(StringUtility.deviceId(getApplicationContext()),
                AppData.user.getUserId(), editPIN.getText().toString());
    }
}
