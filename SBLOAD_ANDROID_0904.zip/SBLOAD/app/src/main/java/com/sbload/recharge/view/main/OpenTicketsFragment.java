package com.sbload.recharge.view.main;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatEditText;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.container.ContainerExecutive;
import com.sbload.recharge.executive.support.OpenTicketsExecutive;
import com.sbload.recharge.model.support.OpenTicketsRequest;
import com.sbload.recharge.view.BaseFragment;

public class OpenTicketsFragment extends BaseFragment implements View.OnClickListener, OpenTicketsExecutive.OpenTicketsDisplay {
    private AppCompatEditText subjectEditText, detailsEditText;
    private OpenTicketsExecutive executive;

    public OpenTicketsFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_open_tickets, container, false);

        //
        // Bind Controls
        //

        subjectEditText = view.findViewById(R.id.edit_subject);
        detailsEditText = view.findViewById(R.id.edit_details);

        //
        // Define Events
        //

        view.findViewById(R.id.btn_side_menu).setOnClickListener(this);
        view.findViewById(R.id.btn_submit).setOnClickListener(this);

        executive = new OpenTicketsExecutive(this);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_side_menu:
                containerExecutive.didPressSideMenuButton();
                break;
            case R.id.btn_submit:
                executive.openTickets();
                break;
        }
    }

    @Override
    public OpenTicketsRequest getOpenTicketsRequest() {
        return new OpenTicketsRequest(AppData.user.getUserId(),
                subjectEditText.getText().toString(), detailsEditText.getText().toString());
    }
}
