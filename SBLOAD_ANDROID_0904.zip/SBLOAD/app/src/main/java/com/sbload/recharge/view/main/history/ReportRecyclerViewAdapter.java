package com.sbload.recharge.view.main.history;

import android.content.Context;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.model.service.ServiceRequest;
import com.sbload.recharge.utility.CommonUtility;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class ReportRecyclerViewAdapter extends RecyclerView.Adapter<ReportRecyclerViewAdapter.ViewHolder> {
    HistoryRecyclerItemEventListener listener;

    private ArrayList<ServiceRequest> histories = new ArrayList<>();
    private Context context;
    ReportRecyclerViewAdapter(Context context, HistoryRecyclerItemEventListener listener) {
        super();
        this.context = context;
        this.listener = listener;
    }


    public void setHistories(ArrayList<ServiceRequest> histories) {
        this.histories = histories;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_report, parent, false);
        return new ReportRecyclerViewAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final ServiceRequest history = histories.get(position);
        Integer type = history.getType();
        Integer serviceId = history.getServiceId();
        int serviceAsset = 0;
        String serviceName = "";
        switch (serviceId) {
            case 1:
                serviceAsset = R.drawable.sms;
                serviceName = "SMS";
                break;
            case 2:
                serviceAsset = R.drawable.prepaidcard;
                serviceName = "Prepaid Card";
                break;
            case 4:
                serviceAsset = R.drawable.billpay;
                serviceName = "BillPay";
                break;
            case 8:
                serviceAsset = R.drawable.flexiload;
                serviceName = "Mobile Topup";
                break;
            case 16:
                serviceAsset = R.drawable.bulk_flexi;
                serviceName = "Bulk Topup";
                break;
            case 32:
                serviceAsset = R.drawable.bkash;
                serviceName = "bKash";
                break;
            case 64:
                serviceAsset = R.drawable.dbbl;
                serviceName = "DBBL";
                break;
            case 128:
                serviceAsset = R.drawable.mcash;
                serviceName = "M-Cash";
                break;
            case 256:
                serviceAsset = R.drawable.ucash;
                serviceName = "U-Cash";
                break;
            case 512:
                serviceAsset = R.drawable.intopup;
                serviceName = "Global Topup";
                break;
            case 1024:
                serviceAsset = R.drawable.nogod;
                serviceName = "Send Money-bKash";
                break;
        }
        holder.serviceImageView.setImageResource(serviceAsset);
        holder.serviceNameTextView.setText(serviceName);
        holder.amountTextView.setText(String.format("Amount: %.2f", (float)history.getAmount()));
        holder.balanceTextView.setText(String.format("%.2f", history.getBalance()));
    }

    @Override
    public int getItemCount() {
        return histories.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView serviceImageView;
        final AppCompatTextView serviceNameTextView, amountTextView;
        final AppCompatTextView balanceTextView;

        ViewHolder(View view) {
            super(view);

            serviceImageView = view.findViewById(R.id.service_image);
            serviceNameTextView = view.findViewById(R.id.txt_service_name);
            amountTextView = view.findViewById(R.id.txt_amount);
            balanceTextView = view.findViewById(R.id.txt_balance);
        }
    }

    public interface HistoryRecyclerItemEventListener {
//        public void didClickEdit(Reseller reseller, int position);
    }
}
