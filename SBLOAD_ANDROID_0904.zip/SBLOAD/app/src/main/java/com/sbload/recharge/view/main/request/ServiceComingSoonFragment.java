package com.sbload.recharge.view.main.request;


import android.os.Bundle;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.Gson;
import com.sbload.recharge.R;
import com.sbload.recharge.model.service.Service;
import com.sbload.recharge.view.BaseFragment;

public class ServiceComingSoonFragment extends BaseFragment implements View.OnClickListener {

    private static final String ARG_SERVICE = "arg_service";
    private AppCompatTextView titleTextView;
    private Service service;


    public ServiceComingSoonFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        service = null;
        if (getArguments() != null) {
            String serviceJson = getArguments().getString(ARG_SERVICE);
            service = new Gson().fromJson(serviceJson, Service.class);
        }
    }

    public static ServiceComingSoonFragment newInstance(String serviceSerialized) {
        ServiceComingSoonFragment fragment = new ServiceComingSoonFragment();
        Bundle args = new Bundle();
        args.putString(ARG_SERVICE, serviceSerialized);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_service_coming_soon, container, false);

        //
        // Bind Controls
        //

        titleTextView = view.findViewById(R.id.txt_title);
        titleTextView.setText(service.getName() + " " + getResources().getString(R.string.request));

        //
        // Define Events
        //

        view.findViewById(R.id.btn_back).setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                popBackStack();
                break;
        }
    }
}
