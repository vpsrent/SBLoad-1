package com.sbload.recharge.view.sidemenu;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.container.ContainerExecutive;
import com.sbload.recharge.style.BaseColors;
import com.sbload.recharge.view.BaseFragment;

import java.util.ArrayList;
import java.util.Arrays;

public class SideMenuFragment extends BaseFragment implements View.OnClickListener, ContainerExecutive.SideMenuDisplay {
    private AppCompatTextView homeButton, addPaymentsButton, changePasswordButton, changePINButton;
    private AppCompatTextView openTicketsButton, aboutUsButton, logoutButton;
    private AppCompatTextView userNameTextView, balanceTextView, currencyTextView;
    public SideMenuFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_side_menu, container, false);

        //
        // Bind Controls
        //

        userNameTextView = view.findViewById(R.id.txt_user_name);
        balanceTextView = view.findViewById(R.id.txt_balance);
        currencyTextView = view.findViewById(R.id.txt_currency);
        homeButton = view.findViewById(R.id.btn_home);
        addPaymentsButton = view.findViewById(R.id.btn_add_payments);
        changePasswordButton = view.findViewById(R.id.btn_change_password);
        changePINButton = view.findViewById(R.id.btn_change_pin);
        openTicketsButton = view.findViewById(R.id.btn_open_tickets);
        aboutUsButton = view.findViewById(R.id.btn_about_us);
        logoutButton = view.findViewById(R.id.btn_logout);

        //
        // Set Event Handler
        //

        view.findViewById(R.id.btn_home).setOnClickListener(this);
        view.findViewById(R.id.btn_add_payments).setOnClickListener(this);
        view.findViewById(R.id.btn_change_password).setOnClickListener(this);
        view.findViewById(R.id.btn_change_pin).setOnClickListener(this);
        view.findViewById(R.id.btn_open_tickets).setOnClickListener(this);
        view.findViewById(R.id.btn_about_us).setOnClickListener(this);
        view.findViewById(R.id.btn_logout).setOnClickListener(this);

        //
        // Set default select menu
        //

        setHighLightItem(ContainerExecutive.SideMenuItem.Home);

        //
        // Set values
        //

        userNameTextView.setText(AppData.user.getUserName());
        containerExecutive.setSideMenuDisplay(this);
        containerExecutive.showAmount();

        return view;
    }

    public void setHighLightItem(ContainerExecutive.SideMenuItem item) {
        ArrayList<AppCompatTextView> itemTextViews =
                new ArrayList<>(Arrays.asList(homeButton, addPaymentsButton, changePasswordButton,
                        changePINButton, openTicketsButton, aboutUsButton, logoutButton));

        //
        // Deselect all items
        //

        for (AppCompatTextView itemTextView : itemTextViews) {
            itemTextView.setTextColor(BaseColors.SBL_GRAY4);
        }

        //
        // Select item
        //

        switch (item) {
            case Home:
                homeButton.setTextColor(BaseColors.SBL_BLUE1);
                break;
            case AddPayments:
                addPaymentsButton.setTextColor(BaseColors.SBL_BLUE1);
                break;
            case ChangePassword:
                changePasswordButton.setTextColor(BaseColors.SBL_BLUE1);
                break;
            case ChangePIN:
                changePINButton.setTextColor(BaseColors.SBL_BLUE1);
                break;
            case OpenTickets:
                openTicketsButton.setTextColor(BaseColors.SBL_BLUE1);
                break;
            case AboutUs:
                aboutUsButton.setTextColor(BaseColors.SBL_BLUE1);
                break;
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_home:
                containerExecutive.didPressSideMenuItem(ContainerExecutive.SideMenuItem.Home);
                break;
            case R.id.btn_add_payments:
                containerExecutive.didPressSideMenuItem(ContainerExecutive.SideMenuItem.AddPayments);
                break;
            case R.id.btn_change_password:
                containerExecutive.didPressSideMenuItem(ContainerExecutive.SideMenuItem.ChangePassword);
                break;
            case R.id.btn_change_pin:
                containerExecutive.didPressSideMenuItem(ContainerExecutive.SideMenuItem.ChangePIN);
                break;
            case R.id.btn_open_tickets:
                containerExecutive.didPressSideMenuItem(ContainerExecutive.SideMenuItem.OpenTickets);
                break;
            case R.id.btn_about_us:
                containerExecutive.didPressSideMenuItem(ContainerExecutive.SideMenuItem.AboutUs);
                break;
            case R.id.btn_logout:
                containerExecutive.didPressSideMenuItem(ContainerExecutive.SideMenuItem.LogOut);
                break;
        }
    }

    @Override
    public void refreshAmount(String amount, String code) {
        balanceTextView.setText(amount);
        currencyTextView.setText(code);
    }
}
